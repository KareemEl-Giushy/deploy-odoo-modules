.. _changelog:

Changelog
=========

`15.0.2.0.0`
------------

- Improve the wizard form view.

- Add the "Language" option to translate label fields.

- Add the product label template 50 x 38 m.

`15.0.1.0.1`
------------

- Add the label option "Border width"

- Add the label option "Human readable barcode"

`15.0.1.0.0`
------------

- Migration from 14.0


